<?php
/**
 * FileDownloadR File Get Processor
 *
 * @package filedownloadr
 * @subpackage processors
 */

use TreehillStudio\FileDownloadR\Processors\FileGetProcessor;

/**
 * Class FileDownloadRFileGetProcessor
 */
class FileDownloadRFileGetProcessor extends FileGetProcessor
{
}

return 'FileDownloadRFileGetProcessor';
