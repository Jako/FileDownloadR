<?php
require_once (dirname(dirname(__FILE__)) . '/fddownloads.class.php');
class fdDownloads_mysql extends fdDownloads {}