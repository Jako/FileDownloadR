<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '# FileDownloadR

A document download listing snippet for MODX Revolution

- Original Evo Author: Kyle Jaebker
- Author: Rico Goldsky <goldsky@virtudraft.com>
- Current Maintainer: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

- This snippet does not reveal your real path to the download, since it uses a hashed download link instead. 
- The files/directories can be located outside of the webroot.
- A download counter is available in the MODX database table.
- Optional the downloaders can be located with their IP (using https://www.ipinfodb.com/)

## Installation

MODX Package Management

## Documentation

For more information please read the documentation on https://jako.github.io/FileDownloadR/

## GitHub Repository

https://github.com/Jako/FileDownloadR

## Third party licenses

This extra includes third party software, for which we are thankful.

* ip2location/ipinfodb-php@1.0.0 [MIT]
* ralouphie/mimey@2.1.0 [MIT]',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [3.3.2] - 2026-02-24

### Fixed

- Fix undefined array key 1 warning in the base Snippet class

## [3.3.1] - 2026-02-09

### Added

- Fill placeholders with uploadMaxCount and uploadMaxSize
- Add the placeholders to the fdWrapperTpl chunk 
- Use a locale aware method for file sizes in every output
- FileDownloadR access policy that contains the file_* and directory_* permissions for handling files in a file system media source

## [3.3.0] - 2025-08-26

### Added

- New uploadMaxCount property for the FileDownload snippet 

### Fixed

- Fix upload with a not set media source

## [3.2.1] - 2025-04-25

### Fixed

- Fix trimming the direct download url
- Fix not shown files with an empty limit
- Fix check of groupByDirectory

## [3.2.0] - 2025-03-21

### Added

- New filedownloadr.extended_file_fields system setting to add extended fields for each uploaded file
- Support for pagination with getPage/pdoPage
- New OnFileDownloadBeforeFileDelete/OnFileDownloadAfterFileDelete plugin event
- Log fatal errors in the plugin events.

### Changed

- Refactor the plugin code of the deactivated FileDownloadEmail and FileDownloadFormSave plugins

### Fixed

- Fix not found files in subdirectories of a media source
- Fix for mediaSourceId in OnFileDownloadBeforeFileUpload not containing the ID but the mediasource object

### Removed

- Drop special handling for Internet Explorer with zip file downloads

## [3.1.4] - 2024-03-12

### Fixed

- Fix xPDO warning \'Encountered empty IN condition with key\' when the path is empty
- imgTypes property of the FileDownloadR snippet has no effect [#6]

## [3.1.3] - 2024-01-29

### Fixed

- Supplying file descriptions does not work [#5]
- imgTypes property of the FileDownloadR snippet has no effect [#6]

## [3.1.2] - 2023-11-07

### Fixed

- Fix updgrade issue to 3.x on sites with a large download count [#4]

## [3.1.1] - 2023-09-21

### Fixed

- Fix PHP warning: Undefined array key

## [3.1.0] - 2023-07-13

### Added

- Upload a file in the current directory
- New uploadFile, uploadFileTypes, uploadGroups and uploadMaxSize property for the FileDownload snippet
- New property countUserDownloads for the FileDownload and FileDownloadLink snippets
- New placeholders count, count_not, count_user and count_user_not in the directory row template counting in all subdirectories
- getDir property can be empty when using mediasources
- New FileDownloadCount snippet for retrieving the download counts of a directory and its subdirectories

### Changed

- Reduce database queries if the download count is not enabled

### Fixed

- Fix browsing while using mediasources

## [3.0.2] - 2023-06-06

### Added

- Add a chunk for the tpl property of the FileDownloadLink snippet
- Add system setting filedownloadr.email_props for the FileDownloadEmail plugin

### Fixed

- Add missing mediaSourceId property to the FileDownloadLink snippet [#2]
- Use only one hash for the same file path

### Changed

- Remove the request properties of FileDownloadR from the referrer to reduce the referrer length.
- Increase the length of the referrer field in the database

## [3.0.1] - 2023-06-06

### Fixed

- Default template of FileDownloadLink doesn\'t work [#1]
- Compatibility with pdoTools 3.x [#1]

## [3.0.0] - 2023-05-03

### Added

- Compatibility with MODX3
- Install composer dependencies directly on the server
- Lexicon entries for all snippet properties
- Invoke plugins with $modx->invokeEvent
- FileDownloadR connector and web/file/get processor

### Fixed

- Fix PHP8 issues

### Changed

- Refactored code
- Switched from BeingTomGreen/IP-User-Location to ip2location/ipinfodb-php

### Removed

- Remove php5-utf8 class
- Internal plugin invokation

## [2.1.0] - August 31, 2016

### Added

- Add file delete support
- Additional snippet properties of the FileDownload snippet are set as placeholders in the associated chunks
- Build process with GPM

### Changed

- Inspected/refactored the current code

## [2.0.0] - 2016-03-29

### Fixed

- Fixed download from nested directories [#48]

## [2.0.0-beta2] - 2016-02-22

### Added

- Removing old data after converting

## [2.0.0-beta1] - 2016-02-19

### Added

- Show empty directory [#42]
- Add media source support [#17][#29]
- Add geolocation support

### Fixed

- Fixed anti hotlink on FURL
- Fixed unicode problems [#8][#28][#33]
- Fixed saltText comparison [#44]
- Fixed duplicate items on Group By Directory [#47]

### Changed

- Update build of fd_count, convert database [#43]
- Rename directory

## [1.1.9] - 2014-12-18

### Fixed

- Fix imageTypes
- Fixed to allow files to download within directories with Revo 2.3.2 [#39]

### Changed

- Rebuild schema
- Change _error and _output types in main class

### Removed

- Remove unused JS files
- Remove filetypes_old images

## [1.1.8] - 2014-10-06

### Fixed

- Not working with get variable in URL [#34]
- Duplicate files on multiple snippet calls [#31][#37][#38]

## [1.1.7] - 2013-09-20

### Fixed

- Fixed [[+fd.image]] only outputs the path to "assets/components/filedownloadr/img/filetypes/" without any file of the
  directory [#21]

## [1.1.6] - 2013-07-01

### Fixed

- Bugfix @CHUNK\'s tpl variable [#18]

## [1.1.5] - 2013-06-06

### Fixed

- Fixed build script

### Changed

- Modified the class\'s construct
- Updated the template parser

## [1.1.4] - 2013-02-24

### Added

- Date sorting with dateFormat property [#12]

### Changed

- Rename directories to follow the namespace

## [1.1.3] - 2013-01-02

### Changed

- Adjustments for PHP 5.4 [#11]

## [1.1.2] - 2012-11-26

### Added

- Create placeholders for dir rows and file rows [#10]
- Add &prefix property for placeholders

## [1.1.1] - 2012-11-15

### Fixed

- Fix breadcrumb [#4]

## [1.1.0] - 2012-10-20

### Fixed

- Rename the package\'s name to fix miscommunication with extra\'s naming style
- Fix the fatal error caused by the invalid package building

## [1.0.0] - 2012-09-28

### Added

- Prevent direct hyperlink from different site or referrer
- Add &fdlid for multiple snippet calls which are having &browseDirectories on the same page
- Add &encoding for internationalization
- Add &tplBreadcrumb and &breadcrumbSeparator for breadcrumbs
- Add [[+fd.hash]] for file
- Add [[+fd.url]] to replace [[+fd.link]] (deprecated)
- Add &downloadByOther (boolean) to avoid download and pass it for other script
- Add plugin examples: FormSave and Email, both require FormIt

### Changed

- Replace the first breadcrumb\'s link to be \'home\' or any lexicon\'s string provided

## [1.0.0.rc5] - 2012-08-25

### Added

- Added &tplWrapperDir and &tplWrapperFile properties to provide separated wrapper templates between directories and files.

## [1.0.0.rc4] - 2021-04-30

### Fixed

- Work out with MODX\'s extra\'s submission cancellation.

## [1.0.0.rc3] - 2021-04-30

### Added

- Added trim utility to overcome the TinyMCE\'s whitespace bug
- Returned the empty result through template.

### Fixed

- Bugfixed fatal error caused by an empty directory

## [1.0.0.rc2] - 2012-02-25

### Added

- Added @BINDINGs to the tpl properties
- Added template for forbidden access

### Fixed

- Bugfixed the multiple usage of fileCss property

### Changed

- Refactored template parser

## [1.0.0.rc1] - 2011-08-25

### Added

### Fixed

### Changed

### Removed

- Fixed the correct realpath

## [1.0.0.b4] - 2011-09-21

### Added

- Added &directLink property to give a direct path for big files

## [1.0.0.b3] - 2011-09-20

### Added

- Added &toPlaceholder property

### Fixed

- Fixed the multicall snippets by adding individual setConfigs method

## [1.0.0.b2] - 2011-09-09

### Added

- Added FileDownloadLink snippet for a single file download
- Added parse template code for FileDownloadLink
- Added &toArray property for both snippets

## [1.0.0.b1] - 2011-08-25

### Added

- Initial release
',
    'setup-options' => 'filedownloadr-3.3.2-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'dadf65c6b3896036c9816e929965813a',
      'native_key' => 'filedownloadr',
      'filename' => 'modNamespace/e1ab7272bfdf3df5c22f58483c872dd5.vehicle',
      'namespace' => 'filedownloadr',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '700aea51a0f74fff3ff1d5bb7b628117',
      'native_key' => 'filedownloadr.exclude_scan',
      'filename' => 'modSystemSetting/85b4c6c9223af34be2aec93c679901d4.vehicle',
      'namespace' => 'filedownloadr',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82862fac397087bc99cb42140561d372',
      'native_key' => 'filedownloadr.use_geolocation',
      'filename' => 'modSystemSetting/7aaff8b165911f65b89bb1ae3f0bdd4b.vehicle',
      'namespace' => 'filedownloadr',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4df594615c30d212915ad933b6ea99a',
      'native_key' => 'filedownloadr.ipinfodb_api_key',
      'filename' => 'modSystemSetting/a2f60ac6b4793e71f95640eadaf1d288.vehicle',
      'namespace' => 'filedownloadr',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30f46ca2292a5c87c97351c940e7d1e0',
      'native_key' => 'filedownloadr.email_props',
      'filename' => 'modSystemSetting/a55d89db247034e4466b8dbc6a46b8e9.vehicle',
      'namespace' => 'filedownloadr',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0447ebb5dbdbe47d12eedc35d58e3e7',
      'native_key' => 'filedownloadr.extended_file_fields',
      'filename' => 'modSystemSetting/2de88340db31b9d3e3c1aa8a0ee8cf48.vehicle',
      'namespace' => 'filedownloadr',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6c580150ad93fdf60b6b832325544db1',
      'native_key' => NULL,
      'filename' => 'modCategory/da6b6125af065493421bc23a2b9932f0.vehicle',
      'namespace' => 'filedownloadr',
    ),
  ),
);