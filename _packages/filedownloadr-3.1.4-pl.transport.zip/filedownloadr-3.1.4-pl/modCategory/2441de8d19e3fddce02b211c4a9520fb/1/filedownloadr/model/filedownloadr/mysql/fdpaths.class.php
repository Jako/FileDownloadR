<?php
require_once (dirname(dirname(__FILE__)) . '/fdpaths.class.php');
class fdPaths_mysql extends fdPaths {}