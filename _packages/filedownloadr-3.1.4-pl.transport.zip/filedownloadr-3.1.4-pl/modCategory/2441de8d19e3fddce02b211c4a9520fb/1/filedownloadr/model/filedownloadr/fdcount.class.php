<?php
class fdCount extends xPDOSimpleObject {}