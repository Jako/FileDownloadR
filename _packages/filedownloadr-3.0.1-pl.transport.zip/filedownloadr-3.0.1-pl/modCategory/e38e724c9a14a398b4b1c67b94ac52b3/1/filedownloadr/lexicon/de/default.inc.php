<?php
/**
 * Default Lexicon Entries for FileDownloadR
 *
 * @package filedownloadr
 * @subpackage lexicon
 */
$_lang['filedownloadr'] = 'FileDownloadR';
$_lang['filedownloadr.breadcrumb.home'] = 'Zurück';
$_lang['filedownloadr.err_save_counter'] = 'Die Anzahl der Downloads konnte nicht gespeichert werden.';
