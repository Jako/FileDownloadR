<?php
require_once (dirname(dirname(__FILE__)) . '/fdcount.class.php');
class fdCount_mysql extends fdCount {}