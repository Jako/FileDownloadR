<?php
/**
 * Default Lexicon Entries for FileDownloadR
 *
 * @package filedownloadr
 * @subpackage lexicon
 */
$_lang['filedownloadr'] = 'FileDownloadR';
$_lang['filedownloadr.breadcrumb.home'] = 'Back';
$_lang['filedownloadr.err_save_counter'] = 'The download count could not be saved.';
