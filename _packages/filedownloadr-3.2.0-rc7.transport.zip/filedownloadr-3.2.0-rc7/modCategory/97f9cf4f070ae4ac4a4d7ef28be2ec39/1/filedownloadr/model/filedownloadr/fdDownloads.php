<?php
/**
 * @package @package filedownloadr
 */
class fdDownloads extends xPDOSimpleObject {}
?>