<?php
/**
 * @package @package filedownloadr
 */
class fdCount extends xPDOSimpleObject {}
?>