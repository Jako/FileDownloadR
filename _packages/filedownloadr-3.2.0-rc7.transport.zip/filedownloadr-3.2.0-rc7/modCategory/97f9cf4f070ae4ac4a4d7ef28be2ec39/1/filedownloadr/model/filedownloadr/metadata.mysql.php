<?php
$xpdo_meta_map = array (
    'xPDOSimpleObject' => 
    array (
        0 => 'filedownloadr\\fdCount',
        1 => 'filedownloadr\\fdDownloads',
        2 => 'filedownloadr\\fdPaths',
    ),
);