<?php
/**
 * @package @package filedownloadr
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/[+class-lowercase+].class.php');
class fdCount_mysql extends fdCount {}
?>