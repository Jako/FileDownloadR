<?php
/**
 * @package @package filedownloadr
 */
class fdPaths extends xPDOSimpleObject {}
?>